# Panel UV / corrugation density fix

Unifies corrugation (гофр) density between roof, walls and wainscot.

## UV / repeat contract

- Mesh `UV.u` = **0..1** across the physical panel (or segment) width
- `span` = that physical width in **metres**
- `repeatX = getPanelRepeat(span)` → density is constant (periods per metre)
- Independent of `DEFAULT_PANEL_WIDTH`

## Files to replace (paths relative to repo root)

```
js/elements/wall/WallOrchestrator.js
js/elements/wainscot/WainscotOrchestrator.js
js/panels/PanelMaterialFactory.js
js/panels/PanelProfiles.js
```

## What changed

### WallOrchestrator.js
- After `ExtrudeGeometry`, UVs are rewritten by `normalizePanelUVs`
- No more metre-space UVs from Three.js default (that made density ∝ panelWidth)
- U 0..1 across panel width, V 0..1 across height

### WainscotOrchestrator.js
- Stopped passing full wall length as `span`
- Each segment gets its own material with `span = segment width`
- Matches roof/wall density

### PanelMaterialFactory.js
- Comment for `resolveRepeatX` documents the unified contract

### PanelProfiles.js
- Comment clarifying `TEXTURE_REPEATS_PER_PANEL`

## Apply

Copy the four files from `js/` over the same paths in your repo, or apply the patches in `diff/`.

Keep `DEFAULT_PANEL_WIDTH = 1` (or your real panel width). Do not use 0.5 as a density workaround.
